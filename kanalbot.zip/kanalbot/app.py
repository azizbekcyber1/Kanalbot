import asyncio
import logging
from aiogram import Bot, Dispatcher, F
from aiogram.types import Message, KeyboardButton, ReplyKeyboardMarkup
from aiogram.enums import ParseMode
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.filters import Command, CommandStart
from aiogram.client.default import DefaultBotProperties

# 🔑 Token va Admin ID
TOKEN = "7368691896:AAFAOX8pfRB9fgxwUeOqqdwgq1xEO0THow0"
ADMIN_ID = 7431790101  # O‘zingning Telegram ID'ingni yoz

# 🤖 Bot va dispatcher
bot = Bot(token=TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher(storage=MemoryStorage())

logging.basicConfig(level=logging.INFO)

# 📋 Holatlar
class ResumeForm(StatesGroup):
    name = State()
    surname = State()
    profession = State()
    age = State()
    salary = State()
    experience = State()
    tech = State()
    contact_time = State()
    format = State()
    goal = State()
    username = State()
    phone = State()

class VacancyForm(StatesGroup):
    company = State()
    position = State()
    tech = State()
    format = State()
    manager = State()
    location = State()
    contact_time = State()
    work_time = State()
    salary = State()
    username = State()
    phone = State()

# 🎛️ Keyboardlar
start_kb = ReplyKeyboardMarkup(
    keyboard=[[KeyboardButton(text="Rezyumi"), KeyboardButton(text="Vakansiya")]],
    resize_keyboard=True
)

skip_kb = ReplyKeyboardMarkup(
    keyboard=[[KeyboardButton(text="/o’tkazib_yuborish")]],
    resize_keyboard=True
)

format_kb = ReplyKeyboardMarkup(
    keyboard=[[KeyboardButton(text="Online"), KeyboardButton(text="Offline")]],
    resize_keyboard=True
)

# 🚀 /start
@dp.message(CommandStart())
async def start(message: Message):
    await message.answer(f"Assalomu alaykum {message.from_user.first_name}!\n\n"
                         "Ish kerakmi? Rezyume yoki vakansiya joylash uchun tanlang:",
                         reply_markup=start_kb)

# ==== Rezyume ====
@dp.message(F.text.lower() == "rezyumi")
async def resume_start(message: Message, state: FSMContext):
    await message.answer("Ismingizni kiriting:", reply_markup=skip_kb)
    await state.set_state(ResumeForm.name)

@dp.message(ResumeForm.name)
async def resume_name(message: Message, state: FSMContext):
    await state.update_data(name=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Familyangizni kiriting:")
    await state.set_state(ResumeForm.surname)

@dp.message(ResumeForm.surname)
async def resume_surname(message: Message, state: FSMContext):
    await state.update_data(surname=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Kasbingizni kiriting:")
    await state.set_state(ResumeForm.profession)

@dp.message(ResumeForm.profession)
async def resume_profession(message: Message, state: FSMContext):
    await state.update_data(profession=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Yoshingizni kiriting:")
    await state.set_state(ResumeForm.age)

@dp.message(ResumeForm.age)
async def resume_age(message: Message, state: FSMContext):
    await state.update_data(age=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Qancha maosh hohlaysiz:")
    await state.set_state(ResumeForm.salary)

@dp.message(ResumeForm.salary)
async def resume_salary(message: Message, state: FSMContext):
    await state.update_data(salary=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Tajribangizni yozing:")
    await state.set_state(ResumeForm.experience)

@dp.message(ResumeForm.experience)
async def resume_experience(message: Message, state: FSMContext):
    await state.update_data(experience=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Qaysi texnologiyalarni bilasiz?")
    await state.set_state(ResumeForm.tech)

@dp.message(ResumeForm.tech)
async def resume_tech(message: Message, state: FSMContext):
    await state.update_data(tech=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Murojaat qilish vaqtini yozing:")
    await state.set_state(ResumeForm.contact_time)

@dp.message(ResumeForm.contact_time)
async def resume_contact_time(message: Message, state: FSMContext):
    await state.update_data(contact_time=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Ish formatini tanlang:", reply_markup=format_kb)
    await state.set_state(ResumeForm.format)

@dp.message(ResumeForm.format)
async def resume_format(message: Message, state: FSMContext):
    await state.update_data(format=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Maqsadingizni yozing:", reply_markup=skip_kb)
    await state.set_state(ResumeForm.goal)

@dp.message(ResumeForm.goal)
async def resume_goal(message: Message, state: FSMContext):
    await state.update_data(goal=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Username (ixtiyoriy):")
    await state.set_state(ResumeForm.username)

@dp.message(ResumeForm.username)
async def resume_username(message: Message, state: FSMContext):
    await state.update_data(username=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Telefon raqamingizni kiriting:")
    await state.set_state(ResumeForm.phone)

@dp.message(ResumeForm.phone)
async def resume_finish(message: Message, state: FSMContext):
    await state.update_data(phone=None if message.text == "/o’tkazib_yuborish" else message.text)
    data = await state.get_data()

    text = (
        "<b>📝 Yangi Rezyume:</b>\n"
        f"👤 Ism: {data.get('name', '—')}\n"
        f"👥 Familya: {data.get('surname', '—')}\n"
        f"🎯 Kasb: {data.get('profession', '—')}\n"
        f"📅 Yosh: {data.get('age', '—')}\n"
        f"💰 Maosh: {data.get('salary', '—')}\n"
        f"🔧 Tajriba: {data.get('experience', '—')}\n"
        f"🛠 Texnologiyalar: {data.get('tech', '—')}\n"
        f"⏰ Murojaat vaqti: {data.get('contact_time', '—')}\n"
        f"🌐 Format: {data.get('format', '—')}\n"
        f"🎯 Maqsad: {data.get('goal', '—')}\n"
        f"✉️ Username: {data.get('username', '—')}\n"
        f"📞 Telefon: {data.get('phone', '—')}"
    )

    await bot.send_message(chat_id=ADMIN_ID, text=text)
    await message.answer("✅ Rezyume adminga yuborildi!", reply_markup=start_kb)
    await state.clear()

# ==== Vakansiya ====
@dp.message(F.text.lower() == "vakansiya")
async def vacancy_start(message: Message, state: FSMContext):
    await message.answer("🏢 Idora yoki tashkilot nomini kiriting:", reply_markup=skip_kb)
    await state.set_state(VacancyForm.company)

@dp.message(VacancyForm.company)
async def vacancy_company(message: Message, state: FSMContext):
    await state.update_data(company=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Qaysi kasb egasi kerak?")
    await state.set_state(VacancyForm.position)

@dp.message(VacancyForm.position)
async def vacancy_position(message: Message, state: FSMContext):
    await state.update_data(position=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Qaysi texnologiyalarni bilishi kerak?")
    await state.set_state(VacancyForm.tech)

@dp.message(VacancyForm.tech)
async def vacancy_tech(message: Message, state: FSMContext):
    await state.update_data(tech=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Ish formatini tanlang:", reply_markup=format_kb)
    await state.set_state(VacancyForm.format)

@dp.message(VacancyForm.format)
async def vacancy_format(message: Message, state: FSMContext):
    await state.update_data(format=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Ma’sul shaxs ismini yozing:", reply_markup=skip_kb)
    await state.set_state(VacancyForm.manager)

@dp.message(VacancyForm.manager)
async def vacancy_manager(message: Message, state: FSMContext):
    await state.update_data(manager=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Hududni yozing:")
    await state.set_state(VacancyForm.location)

@dp.message(VacancyForm.location)
async def vacancy_location(message: Message, state: FSMContext):
    await state.update_data(location=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Murojaat qilish vaqtini yozing:")
    await state.set_state(VacancyForm.contact_time)

@dp.message(VacancyForm.contact_time)
async def vacancy_contact_time(message: Message, state: FSMContext):
    await state.update_data(contact_time=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Ish vaqtini yozing:")
    await state.set_state(VacancyForm.work_time)

@dp.message(VacancyForm.work_time)
async def vacancy_work_time(message: Message, state: FSMContext):
    await state.update_data(work_time=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Maoshni yozing:")
    await state.set_state(VacancyForm.salary)

@dp.message(VacancyForm.salary)
async def vacancy_salary(message: Message, state: FSMContext):
    await state.update_data(salary=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Username yozing:")
    await state.set_state(VacancyForm.username)

@dp.message(VacancyForm.username)
async def vacancy_username(message: Message, state: FSMContext):
    await state.update_data(username=None if message.text == "/o’tkazib_yuborish" else message.text)
    await message.answer("Telefon raqam yozing:")
    await state.set_state(VacancyForm.phone)

@dp.message(VacancyForm.phone)
async def vacancy_finish(message: Message, state: FSMContext):
    await state.update_data(phone=None if message.text == "/o’tkazib_yuborish" else message.text)
    data = await state.get_data()

    text = (
        "<b>📢 Yangi Vakansiya:</b>\n"
        f"🏢 Tashkilot: {data.get('company', '—')}\n"
        f"👨‍💼 Lavozim: {data.get('position', '—')}\n"
        f"🛠 Texnologiya: {data.get('tech', '—')}\n"
        f"🌐 Format: {data.get('format', '—')}\n"
        f"🧑‍💼 Ma’sul shaxs: {data.get('manager', '—')}\n"
        f"📍 Hudud: {data.get('location', '—')}\n"
        f"⏰ Murojaat vaqti: {data.get('contact_time', '—')}\n"
        f"🕰 Ish vaqti: {data.get('work_time', '—')}\n"
        f"💰 Maosh: {data.get('salary', '—')}\n"
        f"✉️ Username: {data.get('username', '—')}\n"
        f"📞 Telefon: {data.get('phone', '—')}"
    )

    await bot.send_message(chat_id=ADMIN_ID, text=text)
    await message.answer("✅ Vakansiya adminga yuborildi!", reply_markup=start_kb)
    await state.clear()

# 🧠 Botni ishga tushurish
async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
